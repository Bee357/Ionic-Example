import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coverpage',
  templateUrl: './coverpage.page.html',
  styleUrls: ['./coverpage.page.scss'],
})
export class CoverpagePage implements OnInit {
  public toc = [
    {
      title: "toc"
    }
  ];

  constructor() { }

  ngOnInit() {
  }

}
